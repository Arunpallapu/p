package com.crud.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crud.dao.BooksDao;
import com.crud.model.Books;


@Service
@Transactional
public class BooksService {
	@Autowired
	BooksDao booksDao;
	
	public List<Books> getAllBooks(){
		List<Books> books = new ArrayList<Books>();
		booksDao.findAll().forEach(bookss->books.add(bookss));
		return books;
	}
	
	public Books getBooksById(int id) {
		return booksDao.findById(id).get();
	}
	
	public void saveUpdate(Books books) {
		booksDao.save(books);
	}
	
	public void save(Books books, int bookid) {
		booksDao.save(books);
	}
	
	public void deleteById(int id) {
		booksDao.deleteById(id);
	}
}
